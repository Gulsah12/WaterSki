﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace UnitTest
{

            [TestClass]
            public class UnitTest1
            {
                [TestMethod]
                public void TestMethod_VoegToeAanRij_ShouldAdd()
                {
                    //Sporter sporter = new Sporter();
                    //Wachtrij.VoegSporterToeAanRij(sporter);
                    //Assert.AreEqual(Wachtrij.Peek(), sporter);
                }
               
            }
        }
    

