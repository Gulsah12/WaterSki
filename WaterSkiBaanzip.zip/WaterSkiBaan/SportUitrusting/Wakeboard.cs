﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterSkiBaan.SportUitrusting
{
    public class Wakeboard : SportArtikel
    {
        public Wakeboard(int id) : base(id) { }
    }
}
