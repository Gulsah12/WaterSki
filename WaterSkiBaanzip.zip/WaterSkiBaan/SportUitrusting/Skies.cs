﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterSkiBaan.SportUitrusting
{
    public class Skies : SportArtikel
    {
        public Skies(int id) : base(id)
        {
            
        }
    }
}
