﻿using System.Collections.Generic;

namespace WaterSkiBaan.Kabelbaan
{
    public class ObstakelsInHetWater
    {
        public List<Obstakel> Obstakels { get; set; } = new List<Obstakel>();
    }
}