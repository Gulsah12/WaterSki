﻿namespace WaterSkiBaan.Kabelbaan
{
    public class Obstakel
    {
        public string Naam { get; set; }
        public int Positie { get; set; }
    }
}